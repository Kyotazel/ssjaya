<div class="card">
    <div class="card-body">
        <div class="text-center">
            <h3>Halaman Tidak Ditemukan</h3>
        </div>
    </div>
</div>