<?php defined('BASEPATH') or exit('No direct script access allowed');

class Test extends BackendController
{
    public function index()
    {
        echo "For Test";
    }
}
